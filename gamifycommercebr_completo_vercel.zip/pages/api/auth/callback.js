import Shopify from '../../../lib/shopify';

export default async function handler(req, res) {
  try {
    const session = await Shopify.Auth.validateAuthCallback(req, res, req.query);
    res.redirect('/');
  } catch (e) {
    console.error(e);
    res.status(500).send(e.message);
  }
}