export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: 'Arial', color: '#333' }}>
      <h1>Gamify Commerce BR</h1>
      <p>App conectado com sua loja Shopify.</p>
    </div>
  );
}